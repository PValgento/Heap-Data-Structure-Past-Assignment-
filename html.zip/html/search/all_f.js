var searchData=
[
  ['setsize',['setSize',['../class_c_s_e_1_1_h_e_a_p.html#a99d1f09503aeb3c053400bf713547af3',1,'CSE::HEAP']]]
];
