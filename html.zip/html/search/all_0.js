var searchData=
[
  ['assignnewdata',['AssignNewData',['../class_c_s_e_1_1_h_e_a_p.html#adc2697d48cfec89b994844714334a568',1,'CSE::HEAP']]]
];
