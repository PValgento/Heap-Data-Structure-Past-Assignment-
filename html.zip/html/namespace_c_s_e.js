var namespace_c_s_e =
[
    [ "ELEMENT", "class_c_s_e_1_1_e_l_e_m_e_n_t.html", "class_c_s_e_1_1_e_l_e_m_e_n_t" ],
    [ "HEAP", "class_c_s_e_1_1_h_e_a_p.html", "class_c_s_e_1_1_h_e_a_p" ]
];